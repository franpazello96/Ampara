﻿using AmparaCRUDApi.Data;
using AmparaCRUDApi.Models;
using AmparaCRUDApi.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AmparaCRUDApi.Controllers
{
    [ApiController]
    [Route("api/donation")]
    public class DonationController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public DonationController(ApplicationDbContext context)
        {
            _context = context;
        }

        [Authorize]
        [HttpPost("register")]
        public IActionResult RegisterDonation([FromBody] DonationDTO dto)
        {
            try
            {
                var cpf = User.FindFirst("cpf")?.Value;
                if (cpf == null)
                    return Unauthorized("Token inválido.");

                var donator = _context.Donators.FirstOrDefault(d => d.CPF == cpf);
                if (donator == null)
                    return NotFound("Doador não encontrado.");

                var donee = _context.Donees.FirstOrDefault(d => d.CNPJ == dto.DoneeCnpj);
                if (donee == null)
                    return NotFound("Instituição não encontrada.");

                var donation = new Donation
                {
                    DonationType = dto.DonationType,
                    Quantity = dto.DonationType == "Dinheiro" ? null : dto.Quantity,
                    Amount = dto.DonationType == "Dinheiro" ? dto.Amount : null,
                    Description = dto.Description,
                    Recurrence = dto.Recurrence,
                    TimeRecurrence = dto.Recurrence ? dto.TimeRecurrence : null,
                    Date = DateTime.UtcNow,
                    DonatorCpf = donator.CPF,
                    DoneeCnpj = donee.CNPJ
                };

                _context.Donations.Add(donation);
                _context.SaveChanges();

                return Ok("Doação registrada com sucesso.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Erro interno: {ex.Message}");
            }
        }
    }
}
